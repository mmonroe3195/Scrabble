import java.io.IOException;

public class ScrabbleMain
{
	public static void main (String [] args) throws IOException
	{
		Scrabble scrabble1 = new Scrabble();
		scrabble1.display();
	}
}

