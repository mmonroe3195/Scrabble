import java.io.IOException;

public class Mainwindowbuilder 
{
	public static void main (String [] args) throws IOException
	{
		Scrabblewindowbuilder scrabble1 = new Scrabblewindowbuilder();
		scrabble1.display();
	}
}

